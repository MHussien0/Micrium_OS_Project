#include "bsp_os.h"
#include "os_cfg.h"
//#include "stm32f446xx.h"

//#if (OS_CFG_DYN_TICK_EN == DEF_ENABLED)
//  static void TIM2_Init(void) {
//	  TIM2->DIER	 |=	 TIM_DIER_UIE_Msk;            /* Enabling Update Interrupt generation */
//  }
//#endif

void BSP_Init(void) {
	BSP_OS_TickInit();
	#if (OS_CFG_DYN_TICK_EN == DEF_ENABLED)          /* Initialize TIM2 for Dynamic Tick feature of uC*/
//		  TIM2_Init();
	#endif
}
