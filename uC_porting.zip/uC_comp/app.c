#include "core_cm4.h"
#include "os.h"
#include "bsp.h"
#include "bsp_os.h"
#include "app_cfg.h"

#include "Board_LED.h"
#include "Board_Buttons.h"   
#include <stdint.h>

#if 0                                    /* Defining if button version of the app will be used */
#define USE_BUTTON
#endif

/* Definition of the Task Control Blocks for three tasks */
static  OS_TCB        start_tsk_tcb;
static  OS_TCB        led1_tcb;
static  OS_TCB        led2_tcb;
#if 0                                    /* Defining if button task's tcb if button used */
static  OS_TCB        button_tcb;
#endif


/* Mutexes */
static OS_MUTEX mutex;	

/* Definition of the Stacks for three tasks */
static  CPU_STK_SIZE  start_tsk_stack[APP_CFG_TASK_STK_SIZE];
static  CPU_STK_SIZE  led1_tsk_stack[APP_CFG_TASK_STK_SIZE];
static  CPU_STK_SIZE  led2_tsk_stack[APP_CFG_TASK_STK_SIZE];
#if 0                                    /* Defining if button stack if button used */
static  CPU_STK_SIZE  button_tsk_stack[APP_CFG_TASK_STK_SIZE];
#endif


/* Timers */
OS_TMR timer;

/* Local variables */
static const int blnk_LED = 0;

/* Prototype of the Task functions */
static void start_task ( void   *p_arg );
static void led1_task ( void   *p_arg );
static void led2_task ( void   *p_arg );
#if 0                                    /* Defining if button task if button used */
static void button_task ( void   *p_arg );
#endif


/* Timer callback */
static void TimerCallback (void *p_tmr, void *p_arg);

/* Delay user function */
static void Delay (uint32_t dlyTicks);

int  main (void)
{
    OS_ERR  err;
	
	BSP_Init();
	CPU_IntDis(); 					/* As soon as the tick timer starts interrupt start to be generated.
										However, the CPU must also be initialized to serve the
										interrupts properly. For this reason interrupts are disabled
										until the OS is ready to handle them */
  CPU_Init();   					/* Init the cpu */
	
	LED_Initialize();     			/* Initialize LED */
	Buttons_Initialize();			/* Initialize button */

    OSInit(&err);						/* Initialize "uC/OS-III, The Real-Time Kernel" */
	
		/* At this point the operating system is ready but still not started.
		Before starting the OS micrium requires to create at least one task. The common layout in
		micrium is to execute a first task (we call ilt the start task). This task is the
		starting point of the system and takes care of creating the following tasks.

		The parameters used to create the first task are defined in this file and in the
		app_cfg.h file (the two files you have to modify when working with MICRIUM */
		
	
    OSTaskCreate((OS_TCB     *) &start_tsk_tcb,               /* Create the start task */
                 (CPU_CHAR   *) "start task",
                 (OS_TASK_PTR ) start_task,
                 (void       *) 0,
                 (OS_PRIO     ) APP_CFG_TASK_PRIO,
                 (CPU_STK    *)&start_tsk_stack[0],
                 (CPU_STK     )(APP_CFG_TASK_STK_SIZE / 10u),
                 (CPU_STK_SIZE) APP_CFG_TASK_STK_SIZE,
                 (OS_MSG_QTY  ) 0,
                 (OS_TICK     ) 0,
                 (void       *) 0,
                 (OS_OPT      )(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
                 (OS_ERR     *)&err);

	  /* Now that you have created the first task you can start the OS and pass control to it */							 
								 
		OSStart(&err);      /* Start multitasking */

    while(DEF_ON){			/* Should Never Get Here */
    };
}


static  void  start_task (void *p_arg)
{
    (void)p_arg;            /* variable used as a return value when executing system calls */

	OS_ERR  err;
	
	BSP_OS_TickEnable();   /* Enable the tick timer and interrupt remember they where initially disabled */		
	
	OSSchedRoundRobinCfg(
		DEF_TRUE,          /* RoundRobin enabled */
		6000u,             /* Ticks per task */
		&err
	);
	
	OSMutexCreate(         /* Create a mutex */
		&mutex,
		"mutex",
		&err
	);
	
	/* Create the led1 task */
	OSTaskCreate((OS_TCB     *) &led1_tcb,               
			 (CPU_CHAR   *) "led1 task",
			 (OS_TASK_PTR ) led1_task,
			 (void       *) 0,
			 (OS_PRIO     ) APP_CFG_L1_TASK_PRIO,
			 (CPU_STK    *)&led1_tsk_stack[0],
			 (CPU_STK     )(APP_CFG_TASK_STK_SIZE / 10u),
			 (CPU_STK_SIZE) APP_CFG_TASK_STK_SIZE,
			 (OS_MSG_QTY  ) 0,
			 (OS_TICK     ) 0,
			 (void       *) 0,
			 (OS_OPT      )(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
			 (OS_ERR     *)&err);
			 
	/* Create the led2 task */
	OSTaskCreate((OS_TCB     *) &led2_tcb,               
			 (CPU_CHAR   *) "led2 task",
			 (OS_TASK_PTR ) led2_task,
			 (void       *) 0,
			 (OS_PRIO     ) APP_CFG_L2_TASK_PRIO,
			 (CPU_STK    *)&led2_tsk_stack[0],
			 (CPU_STK     )(APP_CFG_TASK_STK_SIZE / 10u),
			 (CPU_STK_SIZE) APP_CFG_TASK_STK_SIZE,
			 (OS_MSG_QTY  ) 0,
			 (OS_TICK     ) 0,
			 (void       *) 0,
			 (OS_OPT      )(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
			 (OS_ERR     *)&err);

// #ifdef USE_BUTTON			 
	// /* Create the button task */
	// OSTaskCreate((OS_TCB     *) &button_tcb,               
			 // (CPU_CHAR   *) "button task",
			 // (OS_TASK_PTR ) button_task,
			 // (void       *) 0,
			 // (OS_PRIO     ) APP_CFG_B_TASK_PRIO,
			 // (CPU_STK    *)&button_tsk_stack[0],
			 // (CPU_STK     )(APP_CFG_TASK_STK_SIZE / 10u),
			 // (CPU_STK_SIZE) APP_CFG_TASK_STK_SIZE,
			 // (OS_MSG_QTY  ) 0,
			 // (OS_TICK     ) 0,
			 // (void       *) 0,
			 // (OS_OPT      )(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
			 // (OS_ERR     *)&err);
// #endif
			 
	OSTmrCreate(
		&timer,
		"timer",
		0,
		4,
		OS_OPT_TMR_PERIODIC,
		TimerCallback,
		DEF_NULL,
		&err
	);
	
	OSTmrStart(&timer, &err);
}

static void led1_task (void *p_arg) {
	while (DEF_TRUE) {
		LED_On(blnk_LED);        /* Turn specified LED on and wait for a certain time */
		Delay(200);
		LED_Off(blnk_LED);       /* Turn specified LED off and wait for a certain time */
		Delay(200);
	}
}

static void led2_task (void *p_arg) {
	while (DEF_TRUE) {
		LED_On(blnk_LED);        /* Turn specified LED on and wait for a certain time */
		Delay(800);
		LED_Off(blnk_LED);       /* Turn specified LED off and wait for a certain time */
		Delay(800);
	}
}

// static void button_task (void *p_arg) {
	// int32_t prss_cnt=0;
    // int32_t prss_flag=0;

	// while (DEF_TRUE) {
		// if(Buttons_GetState()){             		  /* Checking if button is pressed */
			// Delay(30);                      		  /* Delay for debouncing */
			// if(Buttons_GetState()){         		  /* Check again if the button is actually pressed */	
				// if(prss_flag==0){     
					// prss_cnt++;             		  /* Increment the button-pressions counter */
						// prss_flag=1;            	  /* Change flag to prevent from incrementing 
														  // while pressing the button */
					// if(prss_cnt==1){
						// OS_RdyListRemove(&led2_TCB);	  /* Removing led2_task from ready list */
						// OS_RdyListInsert(&led1_TCB);   /* Setting led1_task as ready */
					// } else if(prss_cnt==2){ 
						// prss_cnt=0;                   /* Reset the counter */
						// OS_RdyListRemove(&led1_TCB);	  /* Removing led1_task from ready list */
						// OS_RdyListInsert(&led2_TCB);   /* Setting led2_task as ready */
					// }								
				// }
			// } else prss_flag=0;              		  /* If the button is not pressed reset the flag */
		// } else prss_flag=0;                  		  /* If the button is not pressed reset the flag */ 			
	// }
// }

static void TimerCallback (void *p_tmr, void *p_arg) {
    LED_On(0);
		Delay(2000);
}

static void Delay (uint32_t dlyTicks) {
	OS_ERR err;
	
  uint32_t curTicks;
  curTicks = (uint32_t) OSTimeGet(&err);
  
  while (((uint32_t) OSTimeGet(&err) - curTicks) < dlyTicks) { __NOP(); }
}








