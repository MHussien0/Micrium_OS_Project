/*
*********************************************************************************************************
*                                              uC/OS-III
*                                        The Real-Time Kernel
*
*                    Copyright 2009-2022 Silicon Laboratories Inc. www.silabs.com
*
*                                 SPDX-License-Identifier: APACHE-2.0
*
*               This software is subject to an open source license and is distributed by
*                Silicon Laboratories Inc. pursuant to the terms of the Apache License,
*                    Version 2.0 available at www.apache.org/licenses/LICENSE-2.0.
*
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*
*                                   uC/OS-III BOARD SUPPORT PACKAGE
*                                          Dynamic Tick BSP
*
* Filename : bsp_os_dt.c
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*                                             INCLUDE FILES
*********************************************************************************************************
*/

#include  "stm32f4xx.h"
#include  "os_cpu.h"
#include  "cpu.h"
#include  "os.h"
#include  "system_stm32f4xx.h"

/*
*********************************************************************************************************
*                                            LOCAL DEFINES
*********************************************************************************************************
*/

#if (OS_CFG_DYN_TICK_EN == DEF_ENABLED)
#define  TIMER_COUNT_HZ             1000u                       /* Frequency of the Dynamic Tick Timer.                 */
#define  TIMER_TO_OSTICK(count)     (((CPU_INT64U)(count)  * OS_CFG_TICK_RATE_HZ) /      TIMER_COUNT_HZ)
#define  OSTICK_TO_TIMER(ostick)    (((CPU_INT64U)(ostick) * TIMER_COUNT_HZ)      / OS_CFG_TICK_RATE_HZ)
#define  TIM2_IRQ_N                 28
                                                                /* The max timer count should end on a 1 tick boundary. */
#define  TIMER_COUNT_MAX            (DEF_INT_16U_MAX_VAL - (DEF_INT_16U_MAX_VAL % OSTICK_TO_TIMER(1u)))
#endif


/*
*********************************************************************************************************
*                                           LOCAL VARIABLES
*********************************************************************************************************
*/

#if (OS_CFG_DYN_TICK_EN == DEF_ENABLED)
static  OS_TICK  TickDelta = 0u;                                /* Stored in OS Tick units.                             */
#endif


/*
*********************************************************************************************************
*                                      LOCAL FUNCTION PROTOTYPES
*********************************************************************************************************
*/

#if (OS_CFG_DYN_TICK_EN == DEF_ENABLED)
static  void  BSP_DynTick_ISRHandler(void);
#endif


/*
*********************************************************************************************************
*********************************************************************************************************
*                                           GLOBAL FUNCTIONS
*********************************************************************************************************
*********************************************************************************************************
*/


void  BSP_OS_TickISR(void)
{
	OS_CPU_SysTickHandler();
}

/*
*********************************************************************************************************
*                                          BSP_OS_TickInit()
*
* Description : Initializes the tick interrupt for the OS.
*
* Argument(s) : none.
*
* Return(s)   : none.
*
* Note(s)     : (1) Must be called prior to OSStart() in main().
*
*               (2) This function ensures that the tick interrupt is disabled until BSP_OS_TickEn() is
*                   called in the startup task.
*********************************************************************************************************
*/

void  BSP_OS_TickInit (void)
{
    OS_CPU_SysTickInitFreq((CPU_INT32U) SystemCoreClock);
}


/*
*********************************************************************************************************
*                                         BSP_OS_TickEnable()
*
* Description : Enable the OS tick interrupt.
*
* Argument(s) : none.
*
* Return(s)   : none.
*
* Note(s)     : none
*********************************************************************************************************
*/


void  BSP_OS_TickEnable (void)
{
    CPU_IntSrcEn(CPU_INT_SYSTICK);                                               /* Enable Timer interrupt.                              */
}


/*
*********************************************************************************************************
*                                        BSP_OS_TickDisable()
*
* Description : Disable the OS tick interrupt.
*
* Argument(s) : none.
*
* Return(s)   : none.
*
* Note(s)     : none
*********************************************************************************************************
*/


void  BSP_OS_TickDisable (void)
{
    CPU_IntSrcDis(CPU_INT_SYSTICK);                                              /* Disable Timer interrupt.                             */
} 


/*
*********************************************************************************************************
*********************************************************************************************************
**                                      uC/OS-III DYNAMIC TICK
*********************************************************************************************************
*********************************************************************************************************
*/

#if (OS_CFG_DYN_TICK_EN == DEF_ENABLED)
/*
*********************************************************************************************************
*                                            OS_DynTickGet()
*
* Description : Get the number of ticks which have elapsed since the last delta was set.
*
* Argument(s) : none.
*
* Return(s)   : An unsigned integer between 0 and TickDelta, inclusive.
*
* Note(s)     : 1) This function is an INTERNAL uC/OS-III function & MUST NOT be called by the
*                  application.
*
*               2) This function is called with kernel-aware interrupts disabled.
*********************************************************************************************************
*/

OS_TICK  OS_DynTickGet (void)
{
    CPU_INT16U  tmrcnt;


    tmrcnt = TIM2->CNT;                                         /* Read current timer count.                            */

															    /* Check timer interrupt flag.                          */
    if (TIM2->SR & TIM_SR_UIF_Msk) {     
        return (TickDelta);                                     /* Counter Overflow has occurred.                       */
    }

    tmrcnt = TIMER_TO_OSTICK(tmrcnt);                           /* Otherwise, the value we read is valid.               */

    return ((OS_TICK)tmrcnt);
}


/*
*********************************************************************************************************
*                                            OS_DynTickSet()
*
* Description : Sets the number of ticks that the kernel wants to expire before the next interrupt.
*
* Argument(s) : ticks       number of ticks the kernel wants to delay.
*                           0 indicates an indefinite delay.
*
* Return(s)   : The actual number of ticks which will elapse before the next interrupt.
*               (See Note #3).
*
* Note(s)     : 1) This function is an INTERNAL uC/OS-III function & MUST NOT be called by the
*                  application.
*
*               2) This function is called with kernel-aware interrupts disabled.
*
*               3) It is possible for the kernel to specify a delay that is too large for our
*                  hardware timer, or an indefinite delay. In these cases, we should program the timer
*                  to count the maximum number of ticks possible. The value we return should then
*                  be the timer maximum converted into units of OS_TICK.
*********************************************************************************************************
*/

OS_TICK  OS_DynTickSet (OS_TICK  ticks)
{
    CPU_INT16U  tmrcnt;

    tmrcnt = OSTICK_TO_TIMER(ticks);

    if ((tmrcnt >= TIMER_COUNT_MAX) ||                          /* If the delay exceeds our timer's capacity,       ... */
        (tmrcnt ==              0u)) {                          /* ... or the kernel wants an indefinite delay.         */
         tmrcnt = TIMER_COUNT_MAX;                              /* Count as many ticks as we are able.                  */
    }

    TickDelta = TIMER_TO_OSTICK(tmrcnt);                        /* Convert the timer count into OS_TICK units.          */

    TIM2->CR1                                  &=   ~TIM_CR1_CEN_Msk   /* Stop the timer.                                      */
																/* Clear the timer interrupt.                           */
	NVIC->ICPR[(((uint32_t)TIM2_IRQ_N) >> 5UL)] =	(uint32_t)(1UL << (((uint32_t)TIM2_IRQ_N) & 0x1FUL));      
	
    TIM2->ARR                                   =   tmrcnt      /* Set new timeout.                                     */
    TIM2->CNT                                   =   0u          /* Counter Value: 0                                     */
    TIM2->CR1                                  |=   TIM_CR1_CEN_Msk    /* Start the timer.                                     */

    return (TickDelta);                                         /* Return the number ticks that will elapse before  ... */
                                                                /* ... the next interrupt.                              */
}


/*
*********************************************************************************************************
*                                      BSP_DynTick_ISRHandler()
*
* Description : Dynamic Tick ISR handler.
*
* Argument(s) : none.
*
* Return(s)   : none.
*
* Note(s)     : none.
*********************************************************************************************************
*/

static  void  BSP_DynTick_ISRHandler (void)
{
    CPU_SR_ALLOC();


    CPU_CRITICAL_ENTER();
    OSIntEnter();
    CPU_CRITICAL_EXIT();

    OSTimeDynTick(TickDelta);                                   /* Next delta will be set by the kernel.                */

    OSIntExit();
}
#endif                                                      /* End of uC/OS-III Dynamic Tick module.                */


/*
*********************************************************************************************************
*                                             MODULE END
*********************************************************************************************************
*/
