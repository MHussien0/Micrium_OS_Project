void  BSP_OS_TickISR	(void);
void  BSP_OS_TickInit   (void);
void  OS_DynTickGet 	(void);
void  OS_DynTickSet 	(void);
void  BSP_OS_TickEnable (void);
void  BSP_OS_TickDisable(void);
