#include "stm32f4xx.h"                  // Device header
#include "Board_Buttons.h"

#define NUM_KEYS  1                     /* Number of available keys           */

/* Keys for NUCLEO Board */
#define USER    1


/**
  \fn          int32_t Buttons_Initialize (void)
  \brief       Initialize buttons
  \returns
   - \b  0: function succeeded
   - \b -1: function failed
*/
int32_t Buttons_Initialize (void) {

  RCC->AHB1ENR |=  (1ul << 2);                  /* Enable GPIOC clock         */

  GPIOC->MODER   &= ~(3ul << 2*13);
  GPIOC->OSPEEDR &= ~(3ul << 2*13);
  GPIOC->OSPEEDR |=  (1ul << 2*13);
  GPIOC->PUPDR   &= ~(3ul << 2*13);
  return (0);
}


/**
  \fn          int32_t Buttons_Uninitialize (void)
  \brief       De-initialize buttons
  \returns
   - \b  0: function succeeded
   - \b -1: function failed
*/
int32_t Buttons_Uninitialize (void) {

  GPIOC->MODER &= ~(3ul << 2*13);
  return (0);
}


/**
  \fn          uint32_t Buttons_GetState (void)
  \brief       Get buttons state
  \returns     Buttons state
*/
uint32_t Buttons_GetState (void) {

  uint32_t val = 0;

  if ((GPIOC->IDR & (1ul << 13)) == 0) {
    /* USER button */
    val |= USER;
  }

  return (val);
}


/**
  \fn          uint32_t Buttons_GetCount (void)
  \brief       Get number of available buttons
  \return      Number of available buttons
*/
uint32_t Buttons_GetCount (void) {
  return (NUM_KEYS);
}

